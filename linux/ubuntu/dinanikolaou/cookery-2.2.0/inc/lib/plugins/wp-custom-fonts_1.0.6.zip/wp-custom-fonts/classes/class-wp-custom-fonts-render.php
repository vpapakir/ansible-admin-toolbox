<?php
/**
 * WP Custom Fonts Admin Ui
 *
 * @since  1.0.0
 * @package WP_Custom_Fonts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

if ( ! class_exists( 'WP_Custom_Fonts_Render' ) ) :

	/**
	 * WP_Custom_Fonts_Render
	 */
	class WP_Custom_Fonts_Render {

		/**
		 * Instance of WP_Custom_Fonts_Render
		 *
		 * @since  1.0.0
		 * @var (Object) WP_Custom_Fonts_Render
		 */
		private static $instance = null;

		/**
		 * Font base.
		 *
		 * This is used in case of Elementor's Font param
		 *
		 * @since  1.0.5
		 * @var string
		 */
		private static $font_base = 'wpcustomfonts';

		/**
		 * Member Varible
		 *
		 * @var string $font_css
		 */
		protected $font_css = '';

		/**
		 * Instance of WP_Custom_Fonts_Admin.
		 *
		 * @since  1.0.0
		 *
		 * @return object Class object.
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor.
		 *
		 * @since  1.0.0
		 */
		public function __construct() {

			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

			add_action( 'init', array( $this, 'add_on_customizer' ) );

			// Add font files style.
			add_action( 'wp_head', array( $this, 'add_style' ) );
			if ( is_admin() ) {
				add_action( 'enqueue_block_assets', array( $this, 'add_style' ) );
			}

			add_filter( 'elementor/fonts/groups', array( $this, 'elementor_group' ) );
			add_filter( 'elementor/fonts/additional_fonts', array( $this, 'add_elementor_fonts' ) );
		}
		
		/**
		 * Constructor.
		 *
		 * @since  1.0.0
		 */
		public function add_on_customizer() {

			$wpcf_theme_data = wp_get_theme();
			$wpcf_theme_td = $wpcf_theme_data->get( 'TextDomain' );
			$wpcf_theme_array = array( 
				'blossom-feminine-pro' 	=> 'blossom_feminine_pro_',
				'blossom-fashion-pro' 	=> 'blossom_fashion_pro_',
				'blossom-coach-pro' 	=> 'blossom_coach_pro_',
				'blossom-pin-pro' 		=> 'blossom_pin_pro_',
				'blossom-spa-pro' 		=> 'blossom_spa_pro_',
				'blossom-recipe-pro' 	=> 'blossom_recipe_pro_',
				'blossom-travel-pro' 	=> 'blossom_travel_pro_',
				'blossom-wedding-pro' 	=> 'blossom_wedding_pro_',
				'blossom-shop-pro' 		=> 'blossom_shop_pro_',
				'vilva-pro' 			=> 'vilva_pro_',
				'sarada' 				=> 'sarada_',
				'vandana' 				=> 'vandana_',
				'coachpress' 			=> 'coachpress_',
				'cookery' 				=> 'cookery_',
				'blossom-studio-pro' 	=> 'blossom_studio_pro_',
				'seva'					=> 'seva_',
				'wellness-coach'		=> 'wellness_coach_',
				'blossom-floral-pro'    => 'blossom_floral_pro_',
				'blossom-magazine-pro'  => 'blossom_magazine_pro_',
				'blossom-feminine' 		=> 'blossom-feminine-fonts/fonts/',
				'blossom-fashion' 		=> 'blossom-fashion-fonts/fonts/',
				'blossom-coach' 		=> 'blossom_coach_',
				'blossom-consulting' 	=> 'blossom_coach_',
				'blossom-pretty' 		=> 'blossom-feminine-fonts/fonts/',
				'blossom-chic' 			=> 'blossom-feminine-fonts/fonts/',
				'fashion-lifestyle' 	=> 'blossom-fashion-fonts/fonts/',
				'blossom-pin' 			=> 'blossom_pin_',
				'blossom-mommy-blog' 	=> 'blossom-feminine-fonts/fonts/',
				'fashion-stylist' 		=> 'blossom-fashion-fonts/fonts/',
				'life-coach' 			=> 'blossom_coach_',
				'fashion-icon' 			=> 'blossom-fashion-fonts/fonts/',
				'blossom-pinthis' 		=> 'blossom_pin_',
				'blossom-spa' 			=> 'blossom_spa_',
				'blossom-health-coach' 	=> 'blossom_coach_',
				'blossom-beauty' 		=> 'blossom-feminine-fonts/fonts/',
				'blossom-recipe' 		=> 'blossom_recipe_',
				'blossom-diva' 			=> 'blossom-feminine-fonts/fonts/',
				'blossom-speaker' 		=> 'blossom_coach_',
				'fashion-diva' 			=> 'blossom-fashion-fonts/fonts/',
				'blossom-pinit' 		=> 'blossom_pin_',
				'blossom-travel' 		=> 'blossom_travel_',
				'blossom-shop' 			=> 'blossom_shop_',
				'vilva' 				=> 'vilva_',
				'sarada-lite' 			=> 'sarada_lite_',
				'vandana-lite' 			=> 'vandana_lite_',
				'blossom-wedding' 		=> 'blossom_wedding_',
				'hello-fashion' 		=> 'vilva_',
				'vandana-health-coach' 	=> 'vandana_lite_',
				'yummy-recipe' 			=> 'vilva_',
				'travel-nomad' 			=> 'blossom_travel_',
				'coachpress-lite' 		=> 'coachpress_lite_',
				'cookery-lite' 			=> 'cookery_lite_',
				'blossom-studio' 		=> 'blossom_studio_',				
				'coachpress-health'		=> 'coachpress_lite_',
				'cook-recipe'			=> 'cookery_lite_',
				'yoga-fitness' 			=> 'blossom_spa_',
				'minimal-travel'		=> 'vilva_',
				'seva-lite'				=> 'seva_lite_',
				'seva-business'			=> 'seva_lite_',
				'wellness-coach-lite'	=> 'wellness_coach_lite_',
				'perfect-coach'			=> 'blossom_coach_',
				'vedic-spa'				=> 'blossom_spa_',
				'hello-travel'			=> 'blossom_travel_',
				'career-coach'			=> 'coachpress_lite_',
				'fashion-lite'			=> 'vilva_',
				'meditation-coach'		=> 'seva_lite_',
				'blossom-ecommerce'		=> 'blossom_shop_',
				'spicy-recipe'			=> 'cookery_lite_',
				'fashion-pin'			=> 'blossom_pin_',
				'blossom-floral'		=> 'blossom_floral_',
				'business-coach'		=> 'vandana_lite_',
				'floral-fashion'		=> 'blossom_floral_',
				'elegant-travel'		=> 'blossom_floral_',
				'blossom-magazine'		=> 'blossom_magazine_',
				'personal-coach'		=> 'blossom_coach_',
				'fashionable-lite'		=> 'vilva_',
				'leadership-coach'		=> 'coachpress_lite_',
				'travel-diary'			=> 'blossom_pin_',
				'fashion-magazine'		=> 'blossom_magazine_',
				'holistic-coach'		=> 'blossom_coach_',
			);

			if( array_key_exists( $wpcf_theme_td, $wpcf_theme_array ) ) {
				// add Custom Font list into Customizer Body Fonts.
				add_filter( $wpcf_theme_array[$wpcf_theme_td] . 'standard_font', array( $this, 'add_customizer_font_list' ), 10, 1 );

				// add Custom Font list into Customizer H1-H6 Fonts.
				add_filter( $wpcf_theme_array[$wpcf_theme_td] . 'google_fonts', array( $this, 'add_customizer_font_list' ), 10, 1 );
			}
		}

		/**
		 * Enqueue Scripts
		 *
		 * @since 1.0.4
		 */
		public function add_style() {
			$fonts = WP_Custom_Fonts_Taxonomy::get_fonts();
			if ( ! empty( $fonts ) ) {
				foreach ( $fonts  as $load_font_name => $load_font ) {
					$this->render_font_css( $load_font_name );
				}
				?>
				<style type="text/css">
					<?php echo wp_strip_all_tags( $this->font_css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</style>
				<?php
			}
		}
		
		/**
		 * Add Custom Font list into Astra customizer.
		 *
		 * @since  1.0.0
		 * @param string $value selected font family.
		 */
		public function add_customizer_font_list( $value ) {

			// retrieve the license from the database
			$wpcf_add_license        = trim( get_option( 'wpcf_license_key' ) );
			$wpcf_status   = get_option( 'wpcf_license_status' );

			
			$fonts = WP_Custom_Fonts_Taxonomy::get_fonts();
			$custom = array();

			if( $fonts && ( ( !empty( $wpcf_add_license ) && $wpcf_status == 'valid' ) || ( array_key_exists( WP_CUSTOM_FONTS_THEME_TEXTDOMAIN, WP_CUSTOM_FONTS_THEMES ) ) ) ) {
				foreach ( $fonts as $font => $links ) {
					$custom[$font] = $font;
				}
			}

			$allfonts = array_merge( $value, $custom );
			return $allfonts;
		}

		/**
		 * Add Custom Font group to elementor font list.
		 *
		 * Group name "Custom" is added as the first element in the array.
		 *
		 * @since  1.0.5
		 * @param  Array $font_groups default font groups in elementor.
		 * @return Array              Modified font groups with newly added font group.
		 */
		public function elementor_group( $font_groups ) {
			$new_group[ self::$font_base ] = __( 'Custom', 'wp-custom-fonts' );
			$font_groups                   = $new_group + $font_groups;

			return $font_groups;
		}

		/**
		 * Add Custom Fonts to the Elementor Page builder's font param.
		 *
		 * @since  1.0.5
		 * @param Array $fonts Custom Font's array.
		 */
		public function add_elementor_fonts( $fonts ) {

			$all_fonts = WP_Custom_Fonts_Taxonomy::get_fonts();

			if ( ! empty( $all_fonts ) ) {
				foreach ( $all_fonts as $font_family_name => $fonts_url ) {
					$fonts[ $font_family_name ] = self::$font_base;
				}
			}

			return $fonts;
		}


		/**
		 * Enqueue Admin Scripts
		 *
		 * @since 1.0.0
		 */
		public function enqueue_admin_scripts() {

			wp_enqueue_style( 'wp-custom-fonts-css', WP_CUSTOM_FONTS_URI . 'assets/css/wp-custom-fonts.css', array(), WP_CUSTOM_FONTS_VER );
			wp_enqueue_media();
			wp_enqueue_script( 'wp-custom-fonts-js', WP_CUSTOM_FONTS_URI . 'assets/js/wp-custom-fonts.js', array(), WP_CUSTOM_FONTS_VER, false );

		}

		/**
		 * Create css for font-face
		 *
		 * @since 1.0.0
		 * @param array $font selected font from custom font list.
		 */
		private function render_font_css( $font ) {
			$fonts = WP_Custom_Fonts_Taxonomy::get_links_by_name( $font );

			foreach ( $fonts as $font => $links ) :
				$css  = ' @font-face { font-family:' . esc_attr( $font ) . ';';
				$css .= 'src:';
				$arr  = array();
				if ( $links['font_woff_2'] ) {
					$arr[] = 'url(' . esc_url( $links['font_woff_2'] ) . ") format('woff2')";
				}
				if ( $links['font_woff'] ) {
					$arr[] = 'url(' . esc_url( $links['font_woff'] ) . ") format('woff')";
				}
				if ( $links['font_ttf'] ) {
					$arr[] = 'url(' . esc_url( $links['font_ttf'] ) . ") format('truetype')";
				}
				if ( $links['font_otf'] ) {
					$arr[] = 'url(' . esc_url( $links['font_otf'] ) . ") format('opentype')";
				}
				if ( $links['font_svg'] ) {
					$arr[] = 'url(' . esc_url( $links['font_svg'] ) . '#' . esc_attr( strtolower( str_replace( ' ', '_', $font ) ) ) . ") format('svg')";
				}
				$css .= join( ', ', $arr );
				$css .= ';';
				$css .= 'font-display: ' . esc_attr( $links['font-display'] ) . ';';
				$css .= '}' ;
			endforeach;

			$this->font_css .= $css;
		}

		/**
		 * Loads textdomain for the plugin.
		 *
		 * @since 1.0.0
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 'wp-custom-fonts' );
		}
	}

	/**
	 *  Kicking this off by calling 'get_instance()' method
	 */
	WP_Custom_Fonts_Render::get_instance();

endif;





