<?php
/**
 * Plugin Name:     WP Custom Fonts
 * Plugin URI:      http://www.blossomthemes.com/
 * Description:     Custom Fonts allows you to add more fonts that extend formatting options in your site.
 * Author:          BlossomThemes
 * Author URI:      http://www.blossomthemes.com
 * Text Domain:     wp-custom-fonts
 * Version:         1.0.6
 *
 * @package         WP_Custom_Fonts
 */

/**
 * Exit if accessed directly.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/**
 * Set constants.
 */
$wp_custom_fonts_data = wp_get_theme();
define( 'WP_CUSTOM_FONTS_FILE', __FILE__ );
define( 'WP_CUSTOM_FONTS_BASE', plugin_basename( WP_CUSTOM_FONTS_FILE ) );
define( 'WP_CUSTOM_FONTS_DIR', plugin_dir_path( WP_CUSTOM_FONTS_FILE ) );
define( 'WP_CUSTOM_FONTS_URI', plugins_url( '/', WP_CUSTOM_FONTS_FILE ) );
define( 'WP_CUSTOM_FONTS_VER', '1.0.6' );
define( 'WP_CUSTOM_FONTS_THEMES', apply_filters( 'wp_custom_font_themes_array', array( 'coachpress' => 'CoachPress', 'cookery' => 'Cookery', 'wellness-coach' => 'Wellness Coach'  ) ) );
define( 'WP_CUSTOM_FONTS_THEME_TEXTDOMAIN', $wp_custom_fonts_data->get( 'TextDomain' ) );

/**
 * WP Custom Fonts
 */
require_once WP_CUSTOM_FONTS_DIR . 'classes/class-wp-custom-fonts.php';

if ( is_admin() ){          
    require_once WP_CUSTOM_FONTS_DIR . 'updater/wp-custom-fonts-updater.php';
}


/**
 * Redirect to WPFC page on theme activation
*/
function wp_custom_fonts_activate() {
    add_option( 'wp_custom_fonts_do_activation_redirect', true );
}
register_activation_hook( __FILE__, 'wp_custom_fonts_activate' );

/**
 * Redirect to WPFC page on theme activation
*/
function wp_custom_fonts_redirect() {
    if ( get_option( 'wp_custom_fonts_do_activation_redirect', false ) ) {
        delete_option( 'wp_custom_fonts_do_activation_redirect' );
        wp_redirect( admin_url( "edit.php?post_type=wp-custom-fonts&page=wpcf-license_page" ) );
        exit;
    }
}
add_action( 'admin_init', 'wp_custom_fonts_redirect' );

// retrieve the license from the database
$wpcf_add_license        = trim( get_option( 'wpcf_license_key' ) );
$wpcf_status   = get_option( 'wpcf_license_status' );

if( ( !empty( $wpcf_add_license ) && $wpcf_status == 'valid' ) || ( array_key_exists( WP_CUSTOM_FONTS_THEME_TEXTDOMAIN, WP_CUSTOM_FONTS_THEMES ) ) ) {

    require_once WP_CUSTOM_FONTS_DIR . 'includes/wp-custom-fonts-assign.php';

    function wp_custom_fonts_client_css() {

        $fontsRawData   = get_option('wpcf_font_implement');
        $fontsDecodeData     = json_decode( $fontsRawData, true );
        if( ! $fontsDecodeData ) return false;

        $wpcf_upload     = wp_upload_dir();
        $wpcf_upload_url = set_url_scheme( $wpcf_upload['baseurl'] );
        $wpcf_upload_url = $wpcf_upload_url . '/wpcustomfonts/';
        wp_register_style( 'wpcf_client_css', $wpcf_upload_url . 'wpcf.css', array(), get_option( 'wpcf_css_updated_timestamp' ) );
        wp_enqueue_style( 'wpcf_client_css' );
    }
    add_action( 'wp_enqueue_scripts', 'wp_custom_fonts_client_css' );

    function wp_custom_fonts_create_folder() {
        $wpcf_upload         = wp_upload_dir();
        $wpcf_upload_dir     = $wpcf_upload['basedir']. '/wpcustomfonts/';
        
        if ( ! is_dir( $wpcf_upload_dir ) ) {
           mkdir( $wpcf_upload_dir, 0755 );
        }
    }
    add_action('plugins_loaded', 'wp_custom_fonts_create_folder');

}