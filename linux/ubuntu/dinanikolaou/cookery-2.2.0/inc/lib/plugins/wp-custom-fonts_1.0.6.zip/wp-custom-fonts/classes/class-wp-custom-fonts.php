<?php
/**
 * WP Custom fonts - Init
 *
 * @package WP_Custom_Fonts
 */

if ( ! class_exists( 'WP_Custom_Fonts' ) ) {

	/**
	 * WP Custom fonts
	 *
	 * @since 1.0.0
	 */
	class WP_Custom_Fonts {

		/**
		 * Member Varible
		 *
		 * @var object instance
		 */
		private static $instance;

		/**
		 *  Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor function that initializes required actions and hooks
		 */
		public function __construct() {
			require_once WP_CUSTOM_FONTS_DIR . 'includes/class-wp-custom-fonts-taxonomy.php';
			require_once WP_CUSTOM_FONTS_DIR . 'includes/class-wp-custom-fonts-admin.php';

			require_once WP_CUSTOM_FONTS_DIR . 'classes/class-wp-custom-fonts-render.php';
		}
	}

	/**
	 *  Kicking this off by calling 'get_instance()' method
	 */
	WP_Custom_Fonts::get_instance();
}
