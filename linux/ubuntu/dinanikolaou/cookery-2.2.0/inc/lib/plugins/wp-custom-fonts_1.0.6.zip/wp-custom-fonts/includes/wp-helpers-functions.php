<?php
/**
 * WP Custom Fonts Taxonomy
 *
 * @since  1.0.0
 * @package WP_Custom_Fonts
 */

function wpcf_write_css(){

	$wpcf_upload 		= wp_upload_dir();
	$wpcf_upload_dir	= $wpcf_upload['basedir']. '/wpcustomfonts/';

	ob_start();
		$fonts 	= WP_Custom_Fonts_Taxonomy::get_fonts();
		if ( !empty( $fonts ) ) :
			foreach ( $fonts as $font => $links ) :
				$css  = ' @font-face { font-family:' . esc_attr( $font ) . ';';
				$css .= 'src:';
				$arr  = array();
				if ( $links['font_woff_2'] ) {
					$arr[] = 'url(' . esc_url( $links['font_woff_2'] ) . ") format('woff2')";
				}
				if ( $links['font_woff'] ) {
					$arr[] = 'url(' . esc_url( $links['font_woff'] ) . ") format('woff')";
				}
				if ( $links['font_ttf'] ) {
					$arr[] = 'url(' . esc_url( $links['font_ttf'] ) . ") format('truetype')";
				}
				if ( $links['font_otf'] ) {
					$arr[] = 'url(' . esc_url( $links['font_otf'] ) . ") format('opentype')";
				}
				if ( $links['font_svg'] ) {
					$arr[] = 'url(' . esc_url( $links['font_svg'] ) . '#' . esc_attr( strtolower( str_replace( ' ', '_', $font ) ) ) . ") format('svg')";
				}
				$css .= join( ', ', $arr );
				$css .= ';';
				$css .= 'font-display: ' . esc_attr( $links['font-display'] ) . ';';
				$css .= '} ';

				echo $css;
			endforeach;
		endif;	
			
		$fontsRawData 	= get_option('wpcf_font_implement');
		$fontsData		= json_decode($fontsRawData, true);
		if ( !empty( $fontsData ) ) :
			foreach ( $fontsData as $key => $fontData ) : ?>
				<?php echo $fontData['font_elements']; ?>{
					font-family: '<?php echo $fontData['font_key']; ?>' !important;
					<?php if( $fontData['font_size'] ) { ?>
						font-size:<?php echo $fontData['font_size']; ?>px !important;
					<?php }	?>
				}
			<?php endforeach;
		endif;	
		
		$wpcf_style 	= ob_get_contents();
		$wpcfStyleSheetPath	= $wpcf_upload_dir.'/wpcf.css';
		$fileOpen	= fopen( $wpcfStyleSheetPath, 'w' ) or die( "Can't open file" );
		fwrite( $fileOpen, $wpcf_style );
		fclose( $fileOpen );
	
	ob_end_clean();

	update_option( 'wpcf_css_updated_timestamp', time() ); // Time entry for stylesheet version
}